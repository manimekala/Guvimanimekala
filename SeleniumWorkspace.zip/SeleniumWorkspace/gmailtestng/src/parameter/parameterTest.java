package parameter;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class parameterTest {
	
	WebDriver driver ;
	@BeforeMethod
	public  void before() {
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 String url="https://accounts.google.com/SignUp?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ltmpl=default";
		
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();
		 driver.get(url);
	}
	
	@Test
	@Parameters({ "sFirstname","sLastname","sUsername", "sPassword" })
	public void testMethod(String sFirstname,String sLastname,String sUsername,String sPassword )
	{
		driver.findElement(By.id("FirstName")).sendKeys(sFirstname);
		driver.findElement(By.id("LastName")).sendKeys(sLastname);
		driver.findElement(By.id("GmailAddress")).sendKeys(sUsername);
		driver.findElement(By.id("Passwd")).sendKeys(sPassword);
		driver.findElement(By.id("PasswdAgain")).sendKeys(sPassword);
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[5]/fieldset/label[1]/span/div[1]")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[5]/fieldset/label[1]/span/div[2]/div[9]/div")).click();
		driver.findElement(By.id("BirthDay")).sendKeys("10");
		driver.findElement(By.id("BirthYear")).sendKeys("1996");
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[6]/label/div/div")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[6]/label/div/div[2]/div[1]/div")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[7]/table/tbody/tr/td/input")).sendKeys("9698471116");
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[8]/label/input")).sendKeys("manimekala1996@gmail.com");
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[9]/label/div/div/div[1]")).click();
		driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[9]/label/div/div[2]/div[110]/div")).click();
	    driver.findElement(By.id("submitbutton")).click();
	    driver.getWindowHandle();
	    
	    driver.findElement(By.xpath("//*[@id='iagreebutton']")).click();
	}
	@AfterMethod
	public void afterMethod()
	{
		System.out.println("after method");
	}
	
}
