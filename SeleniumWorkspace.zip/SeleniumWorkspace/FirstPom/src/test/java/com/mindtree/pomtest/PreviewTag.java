/**
 * 
 */
package com.mindtree.pomtest;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.mindtree.main.FirstPage;

public class PreviewTag {
	
	@Test
	public void previewTagPost()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver=new ChromeDriver();
		String url1="http://demosite.center/wordpress/wp-login.php";
		
		FirstPage fp=new FirstPage(driver);
		fp.giveUrl(url1);
		fp.giveUserName("admin");
		fp.givePassword("demo123");
		fp.clickLogin();
		fp.givePostPreview("m1041694m", "hello bro!");
	}

}
