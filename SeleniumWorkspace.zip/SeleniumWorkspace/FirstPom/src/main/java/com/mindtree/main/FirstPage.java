/**
 * 
 */
package com.mindtree.main;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

/**
 * @author M1041694
 *
 */
public class FirstPage {
	WebDriver driver;
	By username=By.id("user_login");
	By password=By.id("user_pass");
	By login=By.id("wp-submit");
	By post=By.xpath("//*[@id='menu-posts']/a");
	By addnew=By.xpath("//*[@id='wpbody-content']/div[4]/h2/a");
	By title=By.id("title");
	By postbox=By.id("content");
	By pub=By.id("publish");
	By tag=By.xpath("//*[@id='menu-posts']/div[3]/div/ul/li[4]/a");
	By name=By.id("tag-name");
	By slug=By.id("tag-slug");
	By des=By.id("tag-description");
	By addtag=By.id("submit");
	By pre=By.xpath("//*[@id='post-preview']");
	By admin=By.xpath("//*[@id='wp-admin-bar-my-account']/a");
	By logout=By.linkText("Log Out");
	//By logout = By.className("ab-item");
	

	public FirstPage(WebDriver driver){
	
	this.driver=driver;
	}
	public void giveUrl(String url)
	{
		driver.get(url);
	}
	
	public void giveUserName(String user)
	{
		driver.findElement(username).sendKeys(user);
	}
	public void givePassword(String pass)
	{
		driver.findElement(password).sendKeys(pass);
	}
  public void clickLogin()
   {
	   driver.findElement(login).click();
   }
  public void givePost(String posttitle,String posts)
  {
	  driver.findElement(post).click();	  
	  driver.findElement(addnew).click();
	  driver.findElement(title).sendKeys(posttitle);
	  driver.findElement(postbox).sendKeys(posts);
	  driver.findElement(pub).click();
  }
  public void giveTag(String tagname,String tagslug,String tagdes)
  {

	  driver.findElement(post).click();	  
	  driver.findElement(tag).click();
	  driver.findElement(name).sendKeys(tagname);
	  driver.findElement(slug).sendKeys(tagslug);
	  driver.findElement(des).sendKeys(tagdes);
	  driver.findElement(addtag).click();  
  }
  public void givePostPreview(String posttitle,String posts)
  {

	  driver.findElement(post).click();	  
	  driver.findElement(addnew).click();
	  driver.findElement(title).sendKeys(posttitle);
	  driver.findElement(postbox).sendKeys(posts);
	  driver.findElement(pre).click(); 
	  //driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	  driver.navigate().back();
	  //logout
	  WebElement element= driver.findElement(admin);
	  Actions action = new Actions(driver);
      action.moveToElement(element).build().perform();
      driver.findElement(logout).click();
     /*Select logout = new Select(element);
      logout.selectByVisibleText("Log Out");
  */
      
      
  }
}
