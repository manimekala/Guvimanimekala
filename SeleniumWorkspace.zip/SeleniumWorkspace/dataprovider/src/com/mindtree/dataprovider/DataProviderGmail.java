package com.mindtree.dataprovider;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class DataProviderGmail {
	

	WebDriver driver ;
	@BeforeMethod
	public  void before() {
		System.out.println("starte parallel testing with testNG");
	}
	
	@DataProvider
	public Object[][] getData()
	{
	
	Object[][] data = new Object[3][4];

	// 1st row
	data[0][0] ="kala";
	data[0][1] = "Subramaniyan";
	data[0][2]="kalameka";
	data[0][3]="Mani@7777";
	
	

	// 2nd row
	data[1][0] ="testuser2";
	data[1][1] = "zxcvb";
	data[1][2]="geography123";
	data[1][3]="meka@7777";
	
	
	
	// 3rd row
	data[2][0] ="guestuser3";
	data[2][1] = "pass123";
	data[2][2]="deodanmani";
	data[2][3]="kala@7777";

	return data;
	}
	@Test(dataProvider="getData")
	public void testWithDataProvider(String firstname,String lastname,String username,String password)
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 String url="https://accounts.google.com/SignUp?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ltmpl=default";
		
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();
		 driver.get(url);
	driver.findElement(By.id("FirstName")).sendKeys(firstname);
	driver.findElement(By.id("LastName")).sendKeys(lastname);
	driver.findElement(By.id("GmailAddress")).sendKeys(username);
	driver.findElement(By.id("Passwd")).sendKeys(password);
	driver.findElement(By.id("PasswdAgain")).sendKeys(password);
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[5]/fieldset/label[1]/span/div[1]")).click();
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[5]/fieldset/label[1]/span/div[2]/div[9]/div")).click();
	driver.findElement(By.id("BirthDay")).sendKeys("10");
	driver.findElement(By.id("BirthYear")).sendKeys("1996");
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[6]/label/div/div")).click();
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[6]/label/div/div[2]/div[1]/div")).click();
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[7]/table/tbody/tr/td/input")).sendKeys("9698471116");
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[8]/label/input")).sendKeys("manimekala1996@gmail.com");
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[9]/label/div/div/div[1]")).click();
	driver.findElement(By.xpath("html/body/div[1]/div[2]/div/div[1]/div/form/div[9]/label/div/div[2]/div[110]/div")).click();
    driver.findElement(By.id("submitbutton")).click();
   
}
	
@AfterMethod
public void afterMethod()
{
	System.out.println("after method");
}

}
