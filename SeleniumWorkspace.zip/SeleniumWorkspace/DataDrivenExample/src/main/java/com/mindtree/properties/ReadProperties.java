package com.mindtree.properties;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class ReadProperties {
	
	public void readProp() throws IOException

	{
		File file = new File("D:\\SeleniumWorkspace\\DataDrivenExample\\src\\main\\java\\com\\mindtree\\datadriven\\signup.properties");
		FileInputStream fileInput = new FileInputStream(file);
		Properties obj = new Properties();
		obj.load(fileInput);
		fileInput.close();
		
    }
		  
		
}

