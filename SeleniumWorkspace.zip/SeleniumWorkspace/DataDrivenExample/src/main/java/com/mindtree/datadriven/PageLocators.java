package com.mindtree.datadriven;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import com.mindtree.properties.*;
public class PageLocators 
{
   WebDriver driver;
   @FindBy(id="usernamereg-firstName")
   WebElement firstName;
   @FindBy(id="usernamereg-lastName")
   WebElement lastName;
   @FindBy(id="usernamereg-yid")
   WebElement userName;
   @FindBy(id="usernamereg-password")
   WebElement password;
   @FindBy(id="usernamereg-phone")
   WebElement phone;
   @FindBy(id="usernamereg-month")
   WebElement month;
  Select drop=new Select(month);
   @FindBy(id="usernamereg-day")
   WebElement day;
   @FindBy(id="usernamereg-year")
   WebElement year;
   @FindBy(id="usernamereg-freeformGender")
   WebElement gender;
  public PageLocators(WebDriver driver)
   {
	   this.driver=driver;
	   PageFactory.initElements(driver,this);
   }
 
   
}
