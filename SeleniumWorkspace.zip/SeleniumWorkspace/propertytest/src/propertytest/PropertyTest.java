package propertytest;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
public class PropertyTest {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
			File file = new File("D:\\SeleniumWorkspace\\propertytest\\test.properties");
			FileInputStream fileInput = null;
			try {
				fileInput = new FileInputStream(file);
			}
			catch (FileNotFoundException e) 
			{
				e.printStackTrace();
			}
			Properties prop = new Properties();
			try {
				prop.load(fileInput);
			} 
			catch (IOException e) {
				e.printStackTrace();
			}

			String username=prop.getProperty("username");
			String password=prop.getProperty("password");
			String url=prop.getProperty("url");
			
			System.setProperty("webdriver.chrome.driver", driverPath);
			WebDriver driver = new ChromeDriver();
			//automating gmail login
			driver.get(url);
			System.out.println(username);
			System.out.println(password);
		    driver.findElement(By.id("identifierId")).sendKeys(username);
		    driver.findElement(By.id("identifierNext")).click();
		   
		   // driver.findElement(By.partialLinkText("Enter your password")).click();
		    driver.getCurrentUrl();
		    driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
		   
		    driver.findElement(By.name("password")).sendKeys(password);
		    driver.findElement(By.id("passwordNext")).click();
		    System.out.println("Login");
		   
			
	}
}