package com.keyword;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class KeyWordClass {
	public static WebDriver driver;
	public void openBrowser()
	{
		System.out.println("welcome");
	String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";   
    System.setProperty("webdriver.chrome.driver", driverPath);
    driver=new ChromeDriver();
	}
    public void navigateto(String url)
    {
    	System.out.println("hi");
    	
    	driver.get(url);
    }
    public void enterDetails()
    {
    	driver.findElement(By.id("usernamereg-firstName")).sendKeys("mani");
    	driver.findElement(By.id("usernamereg-lastName")).sendKeys("Subramaniyan");
        driver.findElement(By.id("usernamereg-yid")).sendKeys("manimeka96");
        driver.findElement(By.id("usernamereg-phone")).sendKeys("9698471116");
        WebElement element=driver.findElement(By.id("usernamereg-month"));
        Select option=new Select(element);
        option.selectByVisibleText("September");
        driver.findElement(By.id("usernamereg-day")).sendKeys("10");
       driver.findElement(By.id("usernamereg-year")).sendKeys("1996");
       driver.findElement(By.id("usernamereg-freeformGender")).sendKeys("Female");
    }
    public void Submit()
    {
    	driver.findElement(By.id("reg-submit-button")).click();
    }

}
