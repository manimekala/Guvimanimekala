package com.mt.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtils {
	static XSSFWorkbook book ;
	static XSSFSheet sheet;
	public void excelFile(String path,int sheetnum) throws IOException 
	{
		
		try 
		{
			File file=new File(path);
			FileInputStream fis=new FileInputStream(file);
			book=new XSSFWorkbook(fis);
			 sheet=book.getSheetAt(sheetnum);
			
		  } 
		catch (FileNotFoundException e)
		{
		
			System.out.println(e.getMessage());
		}
	}
   public static String getData(int rownum,int cellnum)
   {
if(cellnum==6||cellnum==11)
{int data1=(int)sheet.getRow(rownum).getCell(cellnum).getNumericCellValue();
   String data="";
   data+=data1;
	return data;
	}  
else
{
 String data=sheet.getRow(rownum).getCell(cellnum).getStringCellValue();

	return data;
	}  
   }

}
