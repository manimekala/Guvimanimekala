package testexe;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.keyword.KeyWordClass;
import com.mt.utils.ExcelUtils;



public class TestExe {
	public static WebDriver driver;
public static void main(String[] args) throws IOException {
		
	String path="C:\\Users\\M1041694\\Documents\\Keyword.xlsx";
		ExcelUtils ex=new ExcelUtils();
		KeyWordClass key=new KeyWordClass();
		ex.excelFile(path,0);
		System.out.println("hi");
		String url="https://login.yahoo.com/account/create?specId=yidReg&altreg=0&intl=in&.done=http://in.mail.yahoo.com";
		for(int i=1;i<5;i++)
		{
		 String keyword=ExcelUtils.getData(i, 1);
			System.out.println(keyword);
		 if(keyword.equals("openBrowser"))
		 {
			 key.openBrowser();
		 }
		 if(keyword.equals("navigateTo"))
		 {
			 System.out.println(url);
			 key.navigateto(url);
		 }
		 if(keyword.equals("enterDetails"))
		 {
			 key.enterDetails();
		 }
		 if(keyword.equals("Submit"))
		 {
			 key.Submit();
		 }
		}
	}

}
