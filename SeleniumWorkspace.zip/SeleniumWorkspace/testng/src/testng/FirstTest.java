package testng;

import org.testng.annotations.Test;

public class FirstTest {
	
	@Test
	public void first()
	{
		System.out.println("hello world");
		
	}
}
