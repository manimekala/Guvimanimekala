package com.mindtree.keyboard;
import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
public class KeyBoardevents {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		String url="http://toolsqa.com/automation-practice-form/";
		driver.get(url);
		driver.manage().window().maximize();
		 WebElement webelement=driver.findElement( By.name("firstname"));
		webelement.sendKeys("Manimekala");
		webelement.sendKeys(Keys.TAB);
		//webelement.sendKeys(Keys.ENTER);
		 WebElement last=driver.findElement( By.name("lastname"));	
        String la=Keys.chord(Keys.SHIFT,"Subramaniyan");
         last.sendKeys(la);
         last.sendKeys(Keys.TAB);
         driver.findElement(By.id("sex-1")).click();
         driver.findElement(By.id("exp-0")).click();
         driver.findElement(By.id("datepicker")).sendKeys("10/09/1996");
         driver.findElement(By.id("profession-1")).click();
         driver.findElement(By.id("photo")).sendKeys("C:\\Users\\M1041694\\Downloads\\back\\profile.jpg");
         driver.findElement(By.id("tool-2")).click();
      WebElement option=   driver.findElement(By.id("continents"));
      Select dropdown= new Select(option);
      dropdown.selectByVisibleText("Europe");
      WebElement option1=   driver.findElement(By.id("selenium_commands"));
      Select dropdown2= new Select(option1);
      dropdown2.selectByVisibleText("Navigation Commands");
      driver.manage().timeouts().implicitlyWait(100,TimeUnit.SECONDS);
      driver.findElement(By.id("submit")).click();
      System.out.println("Login");
     
      
        
         
         
	}

}
