package com.mindtree.example.pagefactory;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.pagefactory.*;

/**
 * Hello world!
 *
 */
public class FirstPageFactory 
{
	WebDriver driver;
	@FindBy(id="user_login")
    WebElement userName;
	@FindBy(id="user_pass")
    WebElement password;
	@FindBy(id="wp-submit")
	WebElement login;
	@FindBy(xpath="//*[@id='menu-posts']/a")
	WebElement post;
	@FindBy(xpath="//*[@id='wpbody-content']/div[4]/h2/a")
	WebElement addNew;
	@FindBy(id="title")
	WebElement title;
    @FindBy(id="content")
    WebElement postBox;
    @FindBy(id="publish")
    WebElement publish;
    @FindBy(id="post-search-input")
    WebElement searchTxt;
    @FindBy(id="search-submit")
    WebElement searchBtn;
	@FindBy(xpath="//*[@id='menu-posts']/div[3]/div/ul/li[4]/a")
	WebElement tag;
	@FindBy(id="tag-name")
	WebElement tagName;
	@FindBy(id="tag-slug")
	WebElement tagSlug;
	@FindBy(id="tag-description")
	WebElement tagDesc;
	@FindBy(id="submit")
	WebElement submitTag;
	@FindBy(xpath="//*[@id='post-preview']")
	WebElement previewTag;
	@FindBy(xpath="//*[@id='wp-admin-bar-my-account']/a")
	WebElement adminHover;
	@FindBy(linkText="Log Out")
	WebElement logout;
	
	FirstPageFactory (WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void giveUrl(String url)
	{
		driver.get(url);
	}
	public void Login(String user,String pass)
	{
		userName.sendKeys(user);
		password.sendKeys(pass);
		login.click();
	}

  public void givePost(String posttitle,String posts)
  {
	 post.click();	  
	 addNew.click();
	  title.sendKeys(posttitle);
	 postBox.sendKeys(posts);
	  publish.click();
  }
  public void giveTag(String tagname,String tagslug,String tagdes)
  {

	  post.click();	  
	 tag.click();
	  tagName.sendKeys(tagname);
	  tagSlug.sendKeys(tagslug);
	 tagDesc.sendKeys(tagdes);
	  submitTag.click();  
  }
  public void givePostPreview(String posttitle,String posts)
  {

	 post.click();	  
	  addNew.click();
	 title.sendKeys(posttitle);
	  postBox.sendKeys(posts);
	  previewTag.click(); 
	  driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
	  driver.navigate().back();
	  WebElement element= adminHover;
	  Actions action = new Actions(driver);
      action.moveToElement(element).build().perform();
      driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS);
       logout.click();
  }
  public void searchPost(String searchPost)
  {
	  post.click();	
	  searchTxt.sendKeys(searchPost);
	  searchBtn.click();
	  
  }
	
	
	
	
}
