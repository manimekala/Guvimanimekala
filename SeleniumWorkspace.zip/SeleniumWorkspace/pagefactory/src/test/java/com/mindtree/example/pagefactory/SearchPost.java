package com.mindtree.example.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SearchPost {
	WebDriver driver;
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("started testing with page factory");	
	}
	@Test
	public void searchPost()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
	     driver=new ChromeDriver();
		String url1="http://demosite.center/wordpress/wp-login.php";
		
		FirstPageFactory fp=new FirstPageFactory(driver);
		fp.giveUrl(url1);
		fp.Login("admin","demo123");
		fp.searchPost("smkp");
	}
	@AfterTest
	public void afterTest()
	{
		System.out.println("started testing with page factory");	
		driver.quit();
	}

}
