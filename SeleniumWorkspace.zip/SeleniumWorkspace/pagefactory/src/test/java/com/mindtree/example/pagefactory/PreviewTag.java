package com.mindtree.example.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class PreviewTag {
	WebDriver driver;
	@BeforeTest
	public void BeforeTest()
	{
		System.out.println("started testing with pagefactory");
	}
	@Test
	public void previewTagPost()
	{
		
		String url1="http://demosite.center/wordpress/wp-login.php";
		
		FirstPageFactory fp=new FirstPageFactory(driver);
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 this.driver=driver;
		 driver=new ChromeDriver();
		 
		fp.giveUrl(url1);
		fp.Login("admin","demo123");
		fp.givePostPreview("m1041694m", "hello bro!");
	}

	   @AfterTest
	   public void afterTest()
	   {
		   System.out.println("done with pagefactoy!!");
		   driver.quit();
	   }

}
