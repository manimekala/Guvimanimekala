package com.mindtree.assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterTest;
import org.testng.annotations.Test;

public class SecondAssignment {
	WebDriver driver;
	@Test
	public void atTest1()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize() ;
		driver.findElement(By.xpath("//*[@id='nav-xshop']/a[2]")).click();
		driver.findElement(By.xpath("//*[@id='widgetFilters']/div[1]/div/span[9]/div/label/span")).click();
		driver.findElement(By.xpath("//*[@id='100_dealView_10']/div/div[2]/div/div[6]/div/span/span/span/a")).click();
	    driver.findElement(By.xpath("//*[@id='result_0']/div/div[2]/div/a/img")).click();
	}
	@Test
	public void atTest2()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize() ;
		driver.findElement(By.xpath("//*[@id='nav-link-accountList']/span[2]")).click();
		driver.findElement(By.id("ap_email")).sendKeys("9698471116");
		driver.findElement(By.id("ap_password")).sendKeys("mani@7777");
		driver.findElement(By.id("signInSubmit")).click();
		 WebElement element = driver.findElement(By.xpath("//*[@id='nav-link-accountList']/span[2]"));
		 Actions action = new Actions(driver);
	     action.moveToElement(element).build().perform();
	     driver.findElement(By.xpath("//*[@id='nav-al-wishlist']/a[3]/span")).click();
	     driver.findElement(By.xpath("//*[@id='infinite-scroll-page-0']/ul/li[14]/a/img")).click();
	     driver.findElement(By.id("add-to-cart-button")).click();
	}
	@AfterTest	
	public void afterTest()
	{
		System.out.println("done testing!!");
	}
	
	
	
	
	
	
	


}
