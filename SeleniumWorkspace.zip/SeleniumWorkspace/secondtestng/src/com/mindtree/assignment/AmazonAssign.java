package com.mindtree.assignment;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AmazonAssign {
	
	WebDriver driver;
	
	@Test
	public void atTest()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 //String url="https://accounts.google.com/SignUp?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ltmpl=default";
		
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize() ;
		WebElement webelement=driver.findElement(By.id("twotabsearchtextbox"));
		webelement.sendKeys("laptops");
		webelement.sendKeys(Keys.ENTER);	
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;
	}
	@Test
	public void atTest2()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 //String url="https://accounts.google.com/SignUp?service=mail&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ltmpl=default";
		
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize() ;
		WebElement webelement=driver.findElement(By.id("twotabsearchtextbox"));
		webelement.sendKeys("mobiles");
		webelement.sendKeys(Keys.ENTER);	
		driver.manage().timeouts().implicitlyWait(10,TimeUnit.SECONDS) ;	
	}
	@AfterTest
	public void afterTest()
	{
		System.out.println("done testing!!!");
		
	}

}
