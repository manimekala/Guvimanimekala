package com.mindtree.assignment;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class ThirdAssignment {
	
	WebDriver driver;
	@BeforeTest
	public void beforeTest()
	{
		System.out.println("started testing!!!");
	}
	/*@Test
	public void atTest1()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize();
		driver.findElement(By.xpath("//*[@id='nav-link-shopall']/span[2]")).click();
		driver.findElement(By.xpath("//*[@id='a-page']/div[2]/div/div[4]/div[1]/div/a[5]")).click();
		driver.findElement(By.xpath("//*[@id='leftNav']/ul[1]/ul/div/li[7]/span/a/span")).click();
		WebElement element=driver.findElement(By.id("sort"));
		 Select dropdown= new Select(element);
	      dropdown.selectByVisibleText("Price: Low to High");	
	}*/
	@Test
	public void atTest2()
	{
		String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		 System.setProperty("webdriver.chrome.driver", driverPath);
		 driver= new ChromeDriver();	
		 String url1="https://www.amazon.com";
		driver.get(url1);
		driver.manage().window().maximize() ;
		driver.findElement(By.xpath("//*[@id='nav-link-accountList']/span[2]")).click();
		driver.findElement(By.id("ap_email")).sendKeys("9698471116");
		driver.findElement(By.id("ap_password")).sendKeys("mani@7777");
		driver.findElement(By.xpath("//*[@id='a-page']/div[1]/div[3]/div/div/form/div/div/div/div[3]/div/div/label/div/label/input")).click();
		driver.findElement(By.id("signInSubmit")).click();
		 WebElement element = driver.findElement(By.xpath("//*[@id='nav-link-accountList']/span[2]"));
		 Actions action = new Actions(driver);
	     action.moveToElement(element).build().perform();
		driver.findElement(By.xpath("//*[@id='nav-al-your-account']/a[14]")).click();
		
	
	}
	
	
	
	
    
	
}
