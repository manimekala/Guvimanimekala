package com.mindtree.test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
public class TestSource {
	
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
			System.setProperty("webdriver.chrome.driver", driverPath);
			WebDriver driver = new ChromeDriver();
			String url="https://peoplehub.mindtree.com/Profile/Pages/Profile.aspx";
			driver.get(url);
			WebElement ele=driver.findElement(By.className("infoText"));
			String output=ele.getText();
			System.out.println(output);
	}

}
