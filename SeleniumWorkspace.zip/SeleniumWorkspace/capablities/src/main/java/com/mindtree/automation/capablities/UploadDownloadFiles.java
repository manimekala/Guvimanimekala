package com.mindtree.automation.capablities;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class UploadDownloadFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		String driverPath ="D:\\final software\\Selenium\\IEDriverServer_x64_3.3.0\\IEDriverServer.exe";
		 System.setProperty("webdriver.ie.driver", driverPath);
		  WebDriver driver=new InternetExplorerDriver();
		  driver.get("http://demo.guru99.com/selenium/upload/");
		  driver.manage().window().maximize();
		 WebElement upload= driver.findElement(By.xpath("//*[@id='uploadfile_0']"));
		 upload.sendKeys("C:\\Users\\M1041694\\Documents\\display dao.txt");
		  driver.findElement(By.id("terms")).click();
		  driver.findElement(By.id("submitbutton")).click();

	}

}
