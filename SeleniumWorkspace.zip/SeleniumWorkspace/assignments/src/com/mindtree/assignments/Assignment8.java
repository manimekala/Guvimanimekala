package com.mindtree.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment8 {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver", driverPath);
			WebDriver driver = new ChromeDriver();
			String url="https://www.amazon.in/";
			driver.get(url);
			 WebElement webelement=driver.findElement(By.id("twotabsearchtextbox"));
			 webelement.sendKeys("mobiles");
			 webelement.sendKeys(Keys.ENTER);
			 driver.findElement(By.xpath("//*[@id='result_1']/div/div[3]/div[1]/a")).click();
			 
	}

}
