package com.mindtree.assignments;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment6 {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args)
	{
		System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		String url="http://toolsqa.wpengine.com/automation-practice-form/ ";
		driver.get(url);
		WebElement element=driver.findElement(By.id("continents"));
		Select select = new Select(element);	
		select.selectByIndex(1);
		select.selectByVisibleText("Africa");
		List<WebElement> options=select.getOptions();
		for(WebElement a:options)
		{
			System.out.println(a.getText());
		}
		
	
		
	}
}
//