package com.mindtree.assignments;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class GmailAttachment {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
		// TODO Auto-generated method stub

    	System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		String url="http://www.gmail.com";
				
		driver.get(url);
	    driver.findElement(By.id("identifierId")).sendKeys("manimekala1996@gmail.com");
	    driver.findElement(By.id("identifierNext")).click();
	   
	   // driver.findElement(By.partialLinkText("Enter your password")).click();
	    driver.getCurrentUrl();
	    driver.manage().timeouts().implicitlyWait(500, TimeUnit.SECONDS);
	   
	    driver.findElement(By.name("password")).sendKeys("2232001smkp");
	    driver.findElement(By.id("passwordNext")).click();
	    System.out.println("Login");
	    driver.manage().window().maximize();
	    driver.findElement(By.xpath("//div[contains(text(),'COMPOSE')]")).click();
	   // driver.getCurrentUrl();
	    driver.findElement(By.xpath("//*[@id=':om']")).sendKeys("manimekala1996@gmail.com");
	  //  driver.getCurrentUrl();
	    driver.findElement(By.xpath("//*[@id=':oa']")).sendKeys("hello!");
	    driver.findElement(By.xpath("//*[@id=':py']")).click();
	    
	    

	}

}
