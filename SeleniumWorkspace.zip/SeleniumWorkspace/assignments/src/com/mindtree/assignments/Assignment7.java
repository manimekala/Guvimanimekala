package com.mindtree.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment7 {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
			System.setProperty("webdriver.chrome.driver", driverPath);
			WebDriver driver = new ChromeDriver();
			String url="http://toolsqa.wpengine.com/automation-practice-table/";
			driver.get(url);
			String out=driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[1]/td[2]")).getText();
			System.out.println(out);
		
			 java.util.List<WebElement> rowdata= driver.findElement(By.className("tsc_table_s13")).findElements(By.tagName("tr"));
			 for (WebElement tr : rowdata) 
			 {
				 java.util.List<WebElement> tabledata = tr.findElements(By.tagName("td"));
				System.out.println("tr  :" +tr.getText());
			
				 if(tr.getText().equals("Clock Tower Hotel"))
				 {
				    for (WebElement td: tabledata) 
				    {
				    	System.out.println(td.getText());
				    }
				 }
			 }
			 
		   
	}

}
