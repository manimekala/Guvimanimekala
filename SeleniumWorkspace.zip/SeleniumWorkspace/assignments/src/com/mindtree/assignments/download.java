package com.mindtree.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class download {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args)
			{
		
		System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.google.co.in/search?q=images&safe=active&tbm=isch&tbo=u&source=univ&sa=X&ved=0ahUKEwjo0t2Y1MDWAhVBL48KHR8lBUYQsAQIKw&biw=1455&bih=722");
			driver.findElement(By.cssSelector("#rg_s > div:nth-child(2) > a > img")).click();
			driver.findElement(By.xpath("//*[@id='irc_cc']/div[2]/div[3]/div[1]/div/div[2]/table[1]/tbody/tr/td[3]/a[1]/span[1]/svg)")).click();
			}
}
