package com.mindtree.assignments;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.testng.annotations.BeforeTest;

public class Assignment2 {
public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
public static void main(String[] args)
		{
	
	System.setProperty("webdriver.chrome.driver", driverPath);
	WebDriver driver = new ChromeDriver();
	String url="http://www.opensourcecms.com/demo/1/319/InterPhoto_Image_Gallery";
	driver.get(url);
	String test1=driver.findElement(By.xpath("//*[@id='menu']/ul/li[1]/a")).getText();
	System.out.println(test1);
		}



}
