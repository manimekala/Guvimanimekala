package com.mindtree.assignments;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Facebook {
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		
	System.setProperty("webdriver.chrome.driver", driverPath);
	WebDriver driver = new ChromeDriver();
	//automating facbook login
	driver.get("https://www.facebook.com/");
	if(driver.findElement(By.id("email"))!=null)
	{
    driver.findElement(By.id("email")).sendKeys("9698471116");
    System.out.println("email present");
	}
	else		
	{
		System.out.println("email field is not present");
	}
	if(driver.findElement(By.id("pass"))!=null)
	{
    driver.findElement(By.id("pass")).sendKeys("mani@100996");
    System.out.println("password field is present");
	}
	else
	{
		System.out.println("password field not present");
	}
	if( driver.findElement(By.id("loginbutton"))!=null)
	{
    driver.findElement(By.id("loginbutton")).click();
    System.out.println("login button is present");
	}
	else
	{System.out.println("login button is not present");
	}
    System.out.println("Login");
   /*//driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
    //driver.manage().timeouts().implicitlyWait(5000, TimeUnit.SECONDS); 
    Thread.sleep(2000);
    driver.findElement(By.id("userNavigationLabel")).click();
    Thread.sleep(4000);
   //driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS); 
    driver.findElement(By.linkText("Log out")).click();
    System.out.println("Logout successfully");
    Thread.sleep(2000);*/
    driver.quit();
	}

}
