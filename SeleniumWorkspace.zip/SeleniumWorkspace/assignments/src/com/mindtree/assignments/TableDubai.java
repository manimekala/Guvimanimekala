package com.mindtree.assignments;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;

public class TableDubai 
{
	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
    public static void main(String[] args) throws InterruptedException 
    {
		
		 System.setProperty("webdriver.chrome.driver",driverPath);
		 WebDriver driver=new ChromeDriver();
		 driver.get("http://toolsqa.com/automation-practice-table/");
 String out=driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[1]/td[2]")).getText();
 System.out.println(out);
 
 
 driver.findElement(By.xpath("//*[@id='content']/table/tbody/tr[1]/td[6]/a")).click();
		
		 
		 
		 
}
}