/**
 * 
 */
package com.mindtree.assignments;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class Assignment4 {

	public static String driverPath = "D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.setProperty("webdriver.chrome.driver", driverPath);
		WebDriver driver = new ChromeDriver();
		String url="https://www.pimcore.org/en/resources/try";
		driver.get(url);
		driver.manage().window().maximize();
		Actions actions = new Actions(driver);
		WebElement submenu=driver.findElement(By.id(""));
		actions.moveToElement(submenu);
		actions.click().build().perform();
	}

}
