package com.mindtree.browsers;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

@Parameters("browsername")
public class BrowserName  {
	
	 @Test
	public void choosebrowser(String browsername)
	{
	if(browsername.equalsIgnoreCase("chrome"))
	{
		String path="D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		WebDriver driver=new ChromeDriver();
		driver.get("https://www.google.com");
	}
	 if(browsername.equalsIgnoreCase("firefox"))
	{
		 String path="D:\\final software\\FirefoxDriver\\geckodriver-v0.11.1-win64\\geckodriver.exe";
			System.setProperty("webdriver.firefox.driver", path);
			/WebDriver driver=new InternetExplorerDriver();
		 driver.get("https://www.google.com");
	}
	if(browsername.equalsIgnoreCase("ie"))
	{
		String path="D:\\final software\\IEDriverServer_x64_3.3.0\\IEDriverServer.exe";
		System.setProperty("webdriver.ie.driver", path);
		WebDriver driver=new InternetExplorerDriver();
	
		driver.get("https://www.google.com");
	}
	}

}
