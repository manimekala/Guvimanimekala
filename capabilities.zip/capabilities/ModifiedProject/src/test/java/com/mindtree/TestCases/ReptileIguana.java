package com.mindtree.TestCases;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mindtree.Action.CardPay;
import com.mindtree.Action.LoginAction;
import com.mindtree.Action.ReptileAction;
import com.mindtree.Action.SignUpAction;
import com.mindtree.ActionInterface.LoginInterface;
import com.mindtree.ActionInterface.PaymentInterface;
import com.mindtree.ActionInterface.ReptileInterface;
import com.mindtree.ActionInterface.SignUpInterface;
import com.mindtree.commonAction.CloseBrowser;
import com.mindtree.commonAction.OpenBrowser;
import com.mindtree.excelData.ReadExcelData;


public class ReptileIguana {
	
	WebDriver driver;
	OpenBrowser open=new OpenBrowser();
	@BeforeTest
	public void beforeTest()
	{
		driver=open.openBrowser();
	}
	@Test(dataProvider="getData")
	public void Iguana(String username,String password,String cpassword,String firstname,String signemail,String lastname,String mobnumber,String address1,String address2,String userCity,String userState,String userPin,String userCountry,String cardno,String carddate) throws InterruptedException
	{
		ReptileInterface action=PageFactory.initElements(driver, ReptileAction.class);
		System.out.println("inside test method");
		//geturl
		action.GetUrl();
		
		//click reptile@ iguana
		action.IguanaSelect();
		
		driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
		//check the price
		String igpri=action.getPrice();
		Float repprice=Float.parseFloat(igpri);
		System.out.println(repprice);
		Assert.assertEquals(repprice, "18.50");
		
		//Checkout the order
		action.addcart();
		
		//Sign up of new user
		SignUpInterface  signnew=PageFactory.initElements(driver, SignUpAction.class);
		signnew.UserSignUp(username, password, cpassword, firstname, signemail, lastname, mobnumber, address1, address2, userCity, userState, userPin,userCountry);
		
		
		
		//Login of user
		LoginInterface userlog=PageFactory.initElements(driver,LoginAction.class);
		userlog.login(username, password);
		
		//Card Payment 
		PaymentInterface payme=PageFactory.initElements(driver,CardPay.class);
		payme.payment(cardno, carddate);
		
		//logout
		action.logout();
		
		
		
	}
	@DataProvider(name="getData")
	public  Object[][] sendData() throws Exception
	{
		System.out.println("coming intoloop");
		ReadExcelData ex=new ReadExcelData();
		ex.excelFile();
		System.out.println(ex);
		Object[][] data = new Object[1][15];
		System.out.println("object created");
	     for(int j=0;j<15;j++)
	     {
		data[0][j]= ex.getExcelData(1,j);
		System.out.println("hellmao");
		
	     }
	     return data;		
	}
	@AfterTest
	public void afterTest()
	{
		CloseBrowser comact=new CloseBrowser();
		comact.close();
		
	}
	
	}
	
	


