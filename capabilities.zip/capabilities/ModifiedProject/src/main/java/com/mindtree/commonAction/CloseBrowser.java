package com.mindtree.commonAction;

import org.openqa.selenium.WebDriver;

public class CloseBrowser {

	static WebDriver driver;
	public void close()
	{
		driver.close();
	}
}
