package com.mindtree.locators;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

public class PaymentLocator {
	@FindBy(id="creditCard")
	public
	 WebElement creditCard;
	@FindBy(id="expiryDate")
	public WebElement expiry;
	@FindBy(xpath=".//*[@id='Catalog']/form/input[2]")
	public WebElement continueto;
	@FindBy(xpath=".//*[@id='order']")
	public WebElement submitOrder;

}
