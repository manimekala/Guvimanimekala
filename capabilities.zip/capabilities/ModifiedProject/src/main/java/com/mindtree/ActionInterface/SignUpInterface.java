package com.mindtree.ActionInterface;

public interface SignUpInterface {

	public void UserSignUp(String UserName,String pass,String confrimpass,String firstName,String signEmail,String lastName,String number,String add1,String add2,String signCity,String signState,String signPin,String signCountry);
	
}
