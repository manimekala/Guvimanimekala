package com.mindtree.excelData;




import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;



public class ReadExcelData {
	String filePath="C:\\Users\\M1041694\\Desktop\\new capa\\ModifiedProject\\ModifiedPets.xlsx";
	int sheetnum=0;
	static XSSFWorkbook book ;
	static XSSFSheet sheet;
	public void excelFile() throws IOException
	
	{
		
		try 
		{
			File file=new File(filePath);
			System.out.println(filePath);
			FileInputStream fis=new FileInputStream(file);
			book=new XSSFWorkbook(fis);
			 sheet=book.getSheetAt(sheetnum);
			System.out.println("hi");
		  } 
		catch (FileNotFoundException e)
		{
		
			System.out.println(e.getMessage());
		}
	}
   public String getExcelData(int rownum,int cellnum)
   {
	  
 String  dataexcel=sheet.getRow(rownum).getCell(cellnum).getStringCellValue();
	    System.out.println(cellnum+"inside excel utils");
	   
	 	return dataexcel;
  
  
}
}


