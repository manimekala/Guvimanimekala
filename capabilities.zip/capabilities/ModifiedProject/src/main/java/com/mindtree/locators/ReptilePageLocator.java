package com.mindtree.locators;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
/**
 * 
 * @author M1041694
 *@Reptile locator
 */
public class ReptilePageLocator {
 
	WebDriver driver;
	@FindAll({@FindBy(xpath="//table//tbody//tr//td")})
	public
	List<WebElement> reptilelist;
	
}