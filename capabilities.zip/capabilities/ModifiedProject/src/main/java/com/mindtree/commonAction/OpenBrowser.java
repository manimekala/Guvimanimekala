package com.mindtree.commonAction;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class OpenBrowser {
	
	static WebDriver driver;
	
	public static WebDriver openBrowser()

	{
		String path="D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
		System.setProperty("webdriver.chrome.driver", path);
		driver=new ChromeDriver();
		//driver.manage().window().maximize();
		return driver;
	}

}
