package com.mindtree.ActionInterface;

public interface PaymentInterface {

	void payment(String card,String exdate);
}
