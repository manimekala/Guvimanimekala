package com.mindtree.locators;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindAll;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
/**
 * 
 * @author M1041694
 * Common locators
 *
 */

public class CommonLocators 
{
	WebDriver driver;
	/*public CommonLocators(WebDriver driver)
	{
		this.driver=driver;
		PageFactory.initElements(driver,this);
	}
	
	*/
	@FindAll({@FindBy(xpath ="//div[@id='QuickLinks']//a" )})
	public List<WebElement> toplinks;
	
	@FindAll({@FindBy(xpath="")})
	public List<WebElement> sidelinks;
	
	@FindBy(linkText="Add to Cart")
	public WebElement add2cart;
	
	//@FindBy(xpath="//table//tbody//td[contains(text(),'$')]//span")
	@FindBy(xpath="//*[@id='Catalog']/table/tbody/tr[2]/td[4]/span")
	public WebElement price;
	
	@FindBy(linkText="Proceed to Checkout")
    public WebElement checkout;
	
	@FindBy(linkText="Register Now!")
	public WebElement register;
	
	@FindBy(linkText="Sign Out")
	public WebElement signout;
	
	@FindBy(linkText="Return to Main Menu")
	public WebElement returnMenu;

	
	
}
