package com.mindtree.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.ActionInterface.ReptileInterface;
import com.mindtree.locators.CommonLocators;
import com.mindtree.locators.ReptilePageLocator;

public class ReptileAction implements ReptileInterface {
	
	

	     WebDriver driver;
		public ReptileAction(WebDriver driver)
		{ 
			this.driver=driver;
			PageFactory.initElements(driver, ReptileAction.class);
		}
		public void GetUrl()
		{
			driver.get("https://jpetstore.cfapps.io/catalog");
		}
		
		/**
		 * selecting iguana
		 */
		
	//CommonLocators loca=PageFactory.initElements(driver, CommonLocators.class);
		CommonLocators loca=new CommonLocators();
		
		public void IguanaSelect()
		{
			System.out.println("inside iguanaselect");
			for(int j=0;j<loca.toplinks.size();j++)
			{
				WebElement current =loca.toplinks.get(j);
				if (current.getText().equalsIgnoreCase("reptiles")) 
				{
					WebElement element = loca.toplinks.get(j - 1);
					System.out.println(element.getText());
					element.click();
				}
				
			}
		
			
			ReptilePageLocator reptile=new ReptilePageLocator();
		

			for (int i = 0; i < reptile.reptilelist.size(); i++)
			{
				WebElement curr = reptile.reptilelist.get(i);
				if (curr.getText().equalsIgnoreCase("iguana")) 
				{
					WebElement myelement = reptile.reptilelist.get(i - 1);
					//System.out.println(myelement.getText());
					myelement.click();
				}
			}
	
		}
		
		/**
		 * Getting Price from UI
		 * @return price
		 */
		public String getPrice(){
			System.out.println("prie value");
			String rep=loca.price.getText();
			System.out.println(rep);
			return rep;
		}
		
		public void addcart()
		{
			loca.add2cart.click();
			loca.checkout.click();
			loca.register.click();
		}
		
		
		
		public void logout()
		{
			loca.signout.click();
		}
		
}
