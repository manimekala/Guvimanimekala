
package com.mindtree.locators;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * 
 * @author M1041694
 * Sign up locators
 *
 */
public class SignUpLocator {
	public WebDriver driver;
	
			@FindBy(xpath=".//input[@id='username']")
			public WebElement username;
			
			@FindBy(xpath=".//input[@id='password']")
			public WebElement password;
			
			@FindBy(xpath=".//input[@id='repeatedPassword']")
			public WebElement repeatpwd;
			
			@FindBy(xpath=".//input[@id='firstName']")
			public WebElement fname;
			
			@FindBy(xpath=".//*[@id='lastName']")
			public WebElement lname;
			
			@FindBy(xpath=".//input[@id='email']")
			public WebElement email;
			
			@FindBy(xpath=".//input[@id='phone']")
			public WebElement phone;
			
			@FindBy(xpath=".//*[@id='address1']")
			public WebElement address1;
			
			@FindBy(xpath=".//*[@id='address2']")
			public WebElement address2;
			
			@FindBy(xpath=".//*[@id='city']")
			public WebElement city;
			
			@FindBy(xpath=".//*[@id='state']")
			public WebElement state;
			
			@FindBy(xpath=".//*[@id='zip']")
			public WebElement zipcode;
			
			@FindBy(xpath=".//*[@id='country']")
			public WebElement country;
			
			@FindBy(xpath=".//*[@id='listOption1']")
			public WebElement list;
			
			@FindBy(xpath=".//*[@id='bannerOption1']")
			public WebElement banner;
			
			@FindBy(xpath=".//*[@id='save']")
			public WebElement save;
}
