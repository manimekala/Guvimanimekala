package com.mindtree.Action;

import com.mindtree.ActionInterface.SignUpInterface;
import com.mindtree.locators.SignUpLocator;

public class SignUpAction implements SignUpInterface {

	SignUpLocator sign=new SignUpLocator();
	public void UserSignUp(String UserName,String pass,String confrimpass,String firstName,String signEmail,String lastName,String number,String add1,String add2,String signCity,String signState,String signPin,String signCountry)
	{
		sign.username.sendKeys(UserName);
		sign.password.sendKeys(pass);
		sign.repeatpwd.sendKeys(confrimpass);
		sign.fname.sendKeys(firstName);
		sign.lname.sendKeys(lastName);
		sign.email.sendKeys(signEmail);
		sign.phone.sendKeys(number);	
		sign.address1.sendKeys(add1);
		sign.address2.sendKeys(add2);
		sign.city.sendKeys(signCity);
		sign.state.sendKeys(signState);
		sign.zipcode.sendKeys(signPin);
		sign.country.sendKeys(signCountry);
		sign.list.click();
		sign.banner.click();
		sign.save.click();
	}
}
