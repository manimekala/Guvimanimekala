package com.mindtree.Action;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

import com.mindtree.ActionInterface.PaymentInterface;
import com.mindtree.locators.PaymentLocator;

public class CardPay implements PaymentInterface{
	
	WebDriver driver;
	public CardPay()
	{ 
		this.driver=driver;
	}
	
	public void payment(String card,String exdate)
	{
		PaymentLocator pay=new PaymentLocator();
		pay.creditCard.sendKeys(card);
		pay.expiry.sendKeys(exdate);
		pay.continueto.click();
		pay.submitOrder.click();
	}
}
