package com.mindtree.ActionInterface;

public interface ReptileInterface {
	
	void GetUrl();
	void IguanaSelect();
	String getPrice();
	void addcart();
	void logout();

}
