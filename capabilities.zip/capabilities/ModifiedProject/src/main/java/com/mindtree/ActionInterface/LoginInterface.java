package com.mindtree.ActionInterface;

public interface LoginInterface {
	void login(String loguser,String logpass);
}
