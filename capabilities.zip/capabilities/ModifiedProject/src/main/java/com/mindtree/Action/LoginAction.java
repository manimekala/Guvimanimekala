package com.mindtree.Action;

import org.openqa.selenium.WebDriver;

import com.mindtree.ActionInterface.LoginInterface;
import com.mindtree.locators.LoginLocator;

public class LoginAction implements LoginInterface{

	
	public WebDriver driver;
	LoginLocator login=new LoginLocator();
	public LoginAction(WebDriver driver)
	{ 
		this.driver=driver;
	}
	
	public void login(String loguser,String logpass)  
	{
		
		login.loginUser.sendKeys(loguser);
		login.loginPass.sendKeys(logpass);
		login.loginbtn.click();
	}
}
