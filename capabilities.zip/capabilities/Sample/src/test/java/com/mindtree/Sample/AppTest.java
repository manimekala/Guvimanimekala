package com.mindtree.Sample;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class AppTest
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest()
	{
	System.out.println("started testing");
	String path="D:\\final software\\ChromeDriver 2.29\\chromedriver.exe";
	   System.setProperty("webdriver.chrome.driver", path);
	   driver=new ChromeDriver();
	}
	@Test
	public void test()
	{

		   	 
		App apptest=PageFactory.initElements(driver, App.class);
		//apptest.openBrowser();
		apptest.openUrl("https://www.flipkart.com");
		apptest.Login("9698471116","mani@7777");
		apptest.searchItem("mobiles");
		
				
		
	}
	
}